# Tournament Tracker Project #
This project is part of the C# From Start to Finish course Tim Corey published on YouTube ([https://www.youtube.com/IAmTimCorey](https://www.youtube.com/IAmTimCorey)). 

## License ##
The Tournament Tracker code, videos, and related content are all restricted to licensed viewers only. If you did not purchase this code directly from Tim Corey, it is not authorized and is an illegal copy. Purchasing these contents directly from Tim Corey authorizes you to use the contents for personal use only. This does not authorize you to copy, share, or otherwise distribute these works.